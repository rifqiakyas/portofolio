    <!-- navbar-->
    <header class="header">
      <nav class="navbar navbar-light navbar-expand-lg fixed-top" id="navbar">
        <div class="container"><a class="navbar-brand" href=#><img src="asset/img/logo.svg" alt="" width="45"></a>
          <button class="navbar-toggler navbar-toggler-end" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><i class="fas fa-bars"></i></button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto">
              <li class="nav-item"><a class="nav-link text-uppercase active" href="#hero">Rumah <span class="sr-only">(current)</span></a></li>
              <li class="nav-item"><a class="nav-link text-uppercase" href="#Tentang">Tentang</a></li>
              <li class="nav-item"><a class="nav-link text-uppercase" href="#Keahlian">Keahlian</a></li>
              <li class="nav-item"><a class="nav-link text-uppercase" href="#education">Pendidikan</a></li>
              <li class="nav-item"><a class="nav-link text-uppercase" href="#Pengalaman">Pengalaman</a></li>
              <li class="nav-item"><a class="nav-link text-uppercase" href="#Kontak">Kontak</a></li>
            </ul>
          </div>
        </div>
      </nav>
    </header>