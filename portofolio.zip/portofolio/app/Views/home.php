<?php foreach ($porto as $row): ?>
  <div class="edu-col">
    <span><?=$row['edu_in']?> <i> kjdsjkhsd </i> <?=$row['edu_out']?></span>
    <h3><?=$row['edu_name']?></h3>
    <p><?=$row['edu_detail']?></p>
  </div>
<?php endforeach; ?>